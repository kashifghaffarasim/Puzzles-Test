import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { FormGroup, FormControl } from '@angular/forms';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, ReactiveFormsModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Design App';
  message='';
  pass='Puzzle is Valid'; 
  error ='Puzzle is Invalid';
  isShowed=false; 
  
  public formData = new FormGroup({
    sudoku: new FormControl(),
  });

  constructor(){

  }

  public onSubmit(): void{
      let skboard = this.formData.value.sudoku;
      let skData = skboard
      .split(',')
      .map((rows: any) => {
        return rows.split('').map((value: any) => {
          let val = value
          console.log(parseInt(value))
          if(parseInt(value) == 0){
            console.log(parseInt(value))
            console.log('checked')
            val = "."
          }
          
          return val;
        });
      });
      
      this.isShowed = true 

      if(skData.length === 9 || skData[0].length === 9){
        let r = this.validSudoku(skData)
        if(r){
          this.message = this.pass;
        } else {
          this.message = this.error;
        }
      } else {
          this.message = "Invalid Board Length";
      }
     
  }

  private validSudoku(board: any){
    for (let i = 0; i < 9; i++) {
        for (let j = 0; j < 9; j++) {
            const value = board[i][j];
            if (value !== '.') {
                if (!this.validRow(board, i, j, value) || !this.validColumn(board, i, j, value) || !this.validBox(board, i, j, value)) {
                    return false;
                }
            }
        }
    }
    return true;
  }

  private validRow(board: any, row: any, col: any, value :any){
    for (let j = 0; j < 8; j++) {
        // check if the current column matches the passed in column
        if (j !== col) {
            if (board[row][j] === value) {
                return false; 
            }
        }
    }
    
    return true;
  }

  private validColumn(board: any, row: any, col: any, value: any){
     // j represents on row
     for (let i = 0; i < 8; i++) {
        // check if the current row matches the passed in row
        if (i !== row) {
            if (board[i][col] === value) {
                return false; 
            }
        }
    }
    return true;
  }

  private validBox(board: any, row: any, col: any, value: any){
    const startRow = row - (row % 3), startCol = col - (col % 3);
    
    for (let i = startRow; i < startRow + 3; i++) {
        for (let j = startCol; j < startCol + 3; j++) {
            if (i !== row && j !== col) {
                if (board[i][j] === value) {
                    return false;
                }
            }
        }
    }
    
    return true;
  }

}
